package com.umgc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.umgc.userAccess.UserAccess;
import com.umgc.userAccess.UserAccessRepository;

/**
 * Testing with TestRestTemplate and @Testcontainers (image mysql:8.0-debian)
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

// activate automatic startup and stop of containers
@Testcontainers
// JPA drop and create table, good for testing

@TestPropertySource(properties = { "spring.jpa.hibernate.ddl-auto=create-drop" })
public class UserAccessControllerTest {

	@LocalServerPort
	private Integer port;

	@Autowired
	private TestRestTemplate restTemplate;

	private String BASEURI;

	@Autowired
	UserAccessRepository userAccessRepository;

	// static, all tests share this mysql container
	@Container
	@ServiceConnection
	static MySQLContainer<?> mysql = new MySQLContainer<>("mysql:8.0-debian");

	@BeforeEach
	void testSetUp() {

		BASEURI = "http://localhost:" + port;

		userAccessRepository.deleteAll();

		UserAccess newUserAccessAAA = new UserAccess("LocationA");
		UserAccess newUserAccessBBB = new UserAccess("LocationB");
		UserAccess newUserAccessCCC = new UserAccess("LocationC");
		UserAccess newUserAccessDDD = new UserAccess("LocationD");

		userAccessRepository.saveAll(List.of(newUserAccessAAA, newUserAccessBBB, newUserAccessCCC, newUserAccessDDD));
	}

	@Test
	void testFindAll() {

		// find all Users and return List<User>
		ParameterizedTypeReference<List<UserAccess>> typeRef = new ParameterizedTypeReference<>() {
		};
		ResponseEntity<List<UserAccess>> response = restTemplate.exchange(BASEURI + "/Users", HttpMethod.GET, null, typeRef);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(4, response.getBody().size());

	}
/*
	//@Test
	public void testCreate() {

		// Create a new User EEE

		UserAccess newUser = new UserAccess("EEE", "RoleE", "CardE", "StatusE");
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		HttpEntity<UserAccess> request = new HttpEntity<>(newUser, headers);

		// test POST save
		ResponseEntity<UserAccess> responseEntity = restTemplate.postForEntity(BASEURI + "/Users", request, UserAccess.class);

		assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());

		// find User EEE
		List<UserAccess> list = userRepository.findByName("EEE");

		// Test User EEE details
		UserAccess user = list.get(0);
		assertEquals("EEE", user.getName());
		assertEquals("RoleE", user.getRole());
		assertEquals("CardE", user.getCardId());
		assertEquals("StatusE", user.getStatus());

	}
	
	//@Test
	public void testDeleteById() {

		// Create a new User EEE

		UserAccess newUser = new UserAccess("EEE", "RoleE", "CardE", "StatusE");
		
		userRepository.save(newUser);

		// find User EEE
		Long newUserId = newUser.getId();
		Optional<UserAccess> result = userRepository.findById(newUserId);
        assertTrue(!result.isEmpty());
		
        // Delete User EEE
		userRepository.deleteById(newUserId);
		
        result = userRepository.findById(newUserId);
        assertTrue(result.isEmpty());
	}
*/	
}